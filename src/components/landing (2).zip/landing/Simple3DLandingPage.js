"use client";

import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  ShieldCheck,
  Zap,
  Cpu,
  EyeOff,
  Code2,
  FileText,
  ChevronDown,
  CheckCircle2,
  Mic,
  ArrowRight,
  MonitorCheck,
  Terminal,
  Layers,
  HelpCircle,
  Video,
  Play,
  Pause,
  Volume2,
  Briefcase,
  Target,
  Award,
  Star,
  Users,
  Check,
  XCircle,
  TrendingUp,
  Laptop,
  Radio,
  FileCheck,
  Lock,
  Mail,
  Globe,
  Move,
  Maximize2,
  Copy,
  ThumbsUp,
  ThumbsDown,
} from 'lucide-react';
import Navbar3D from './Navbar3D';
import ParakeetPricingView from '../pricing/ParakeetPricingView';
import './ParakeetLanding.css';

const SIM_PRESETS = [
  {
    id: 'system_design',
    title: '1. System Design: Distributed Rate Limiter',
    category: 'Architecture',
    question: 'How would you design a distributed API rate limiter capable of handling 500,000 req/sec?',
    talkingPoints: [
      'Algorithm: Token Bucket or Sliding Window Log based on traffic bursts',
      'Storage: Distributed Redis cluster with Redis cell / Lua scripts for atomic increments',
      'Fallback: Local in-memory leaky bucket in API Gateway if Redis connection drops',
      'Header Response: X-RateLimit-Limit, X-RateLimit-Remaining, Retry-After',
    ],
    code: `// Atomic Token Bucket check via Redis Lua script
local key = KEYS[1]
local limit = tonumber(ARGV[1])
local current = tonumber(redis.call('get', key) or "0")

if current + 1 > limit then
  return 0 -- Rate limit exceeded
else
  redis.call('INCRBY', key, 1)
  if current == 0 then redis.call('EXPIRE', key, 60) end
  return 1 -- Allowed
end`,
  },
  {
    id: 'javascript',
    title: '2. Frontend: JS Event Loop & Concurrency',
    category: 'JavaScript Runtime',
    question: 'Can you explain the exact difference between Microtasks and Macrotasks in JavaScript?',
    talkingPoints: [
      'Call Stack: Executes synchronous frames first until empty',
      'Microtask Queue: Processes Promise.then(), catch(), queueMicrotask() immediately after each call stack tick',
      'Macrotask Queue: Processes setTimeout, setInterval, I/O events between render steps',
      'Priority: All microtasks are exhausted before the next macrotask is dequeued',
    ],
    code: `console.log('1: Sync');
setTimeout(() => console.log('2: Macrotask Timeout'), 0);
Promise.resolve().then(() => console.log('3: Microtask Promise'));
queueMicrotask(() => console.log('4: Microtask Queue'));
console.log('5: Sync');

// Output order: 1 -> 5 -> 3 -> 4 -> 2`,
  },
  {
    id: 'algorithms',
    title: '3. Data Structures: LRU Cache Implementation',
    category: 'Algorithms',
    question: 'Design and implement a data structure for Least Recently Used (LRU) cache with O(1) get and put.',
    talkingPoints: [
      'Data Structure: Hash Map + Doubly Linked List',
      'O(1) Lookup: Hash Map stores keys mapped to linked list nodes',
      'O(1) Eviction: Doubly Linked List head tracks most recent, tail tracks least recent',
      'Put strategy: If key exists, update value and move to head; if at capacity, remove tail node',
    ],
    code: `class LRUCache {
  constructor(capacity) {
    this.capacity = capacity;
    this.map = new Map(); // Preserves insertion order in JS
  }
  get(key) {
    if (!this.map.has(key)) return -1;
    const val = this.map.get(key);
    this.map.delete(key);
    this.map.set(key, val); // Move to most recent
    return val;
  }
  put(key, value) {
    if (this.map.has(key)) this.map.delete(key);
    else if (this.map.size >= this.capacity) {
      this.map.delete(this.map.keys().next().value); // Evict oldest
    }
    this.map.set(key, value);
  }
}`,
  },
  {
    id: 'behavioral',
    title: '4. Behavioral: Production Outage (STAR)',
    category: 'STAR Framework',
    question: 'Tell me about a time when a critical production issue occurred and how you resolved it under pressure.',
    talkingPoints: [
      'Situation: Database connection pool exhaustion caused 45% request drop during Black Friday',
      'Task: Led war-room mitigation to restore 99.9% uptime within 15 minutes',
      'Action: Identified leaking unclosed queries via APM traces, rolled back bad deployment, dialed up connection pools',
      'Result: Service recovered in 11 minutes; introduced automated connection leak linters and circuit breakers',
    ],
    code: null,
  },
];

const COMPATIBLE_PLATFORMS = [
  'Zoom',
  'Google Meet',
  'Microsoft Teams',
  'Webex',
  'CoderPad',
  'HackerRank',
  'LeetCode',
  'CodeSignal',
];

const CAREER_SUITE = [
  {
    id: 'resume',
    title: 'ATS Smart Resume Builder',
    subtitle: 'Pass ATS filters with automated scoring & keyword extraction',
    icon: FileText,
    color: '#10b981',
    bgColor: 'rgba(16, 185, 129, 0.1)',
    features: [
      'Scores CV against 50+ real ATS algorithms',
      'One-click keyword optimization from target JD',
      'Structured bullet point rewrites using metric-driven STAR',
      'Clean PDF download formatted for tech recruiters',
    ],
  },
  {
    id: 'gap_analyzer',
    title: 'Job Match & Gap Analyzer',
    subtitle: 'Paste any JD to see your match rate and missing qualifications',
    icon: Target,
    color: '#38bdf8',
    bgColor: 'rgba(56, 189, 248, 0.1)',
    features: [
      'Instant Match % Calculation based on your experience',
      'Identifies missing technical requirements & frameworks',
      'Generates predictive interview questions for the role',
      'Prepares tailored study guides to bridge knowledge gaps',
    ],
  },
  {
    id: 'cover_letter',
    title: 'AI Cover Letter Generator',
    subtitle: 'Tailored, narrative cover letters in less than 30 seconds',
    icon: Award,
    color: '#a855f7',
    bgColor: 'rgba(168, 85, 247, 0.1)',
    features: [
      'Connects your actual projects to company mission',
      'Eliminates generic templates; sounds human & polished',
      'Multiple tone settings: Executive, Casual, or Technical',
      'Editable drafts with export to Word & Markdown',
    ],
  },
  {
    id: 'tracker',
    title: 'Application Pipeline Tracker',
    subtitle: 'Full lifecycle tracking from application to final offer',
    icon: Briefcase,
    color: '#f59e0b',
    bgColor: 'rgba(245, 158, 11, 0.1)',
    features: [
      'Kanban board: Wishlist, Applied, Interview, Offer',
      'Interview countdowns with linked practice sessions',
      'Logs notes, recruiter feedback & salary negotiations',
      'Analytics on application-to-interview conversion rate',
    ],
  },
];

const TESTIMONIALS = [
  {
    name: 'Alex R.',
    role: 'Senior Distributed Systems Engineer',
    company: 'Tier-1 FinTech ($185k Offer)',
    avatar: 'AR',
    rating: 5,
    quote:
      'Feonix AI was an absolute game changer. In my system design round, I was asked about partition rebalancing in Kafka. The teleprompter gave me the exact trade-offs in under a second. Landed the senior offer with a 40% pay raise.',
  },
  {
    name: 'Sophia K.',
    role: 'Full-Stack Team Lead',
    company: 'Unicorn SaaS Series C',
    avatar: 'SK',
    rating: 5,
    quote:
      'The 100% stealth guarantee is real. I shared my entire desktop on Zoom and Google Meet while doing live coding on CoderPad. The teleprompter was completely invisible to the interviewer. Unshakeable confidence.',
  },
  {
    name: 'Marcus D.',
    role: 'Lead Cloud Architect',
    company: 'Fortune 100 Enterprise',
    avatar: 'MD',
    rating: 5,
    quote:
      'I used the AI Mock Coach to drill behavioral and technical questions every night for a week. The real-time speech feedback and filler word tracker made my delivery crisp and executive-ready.',
  },
];

const FAQS = [
  {
    q: 'Is Feonix AI undetectable during live video calls?',
    a: 'Yes. Feonix AI utilizes native desktop window protection that is completely excluded from window capture and desktop screen sharing on Zoom, Microsoft Teams, Google Meet, and browser tabs. Only you see the floating teleprompter overlay.',
  },
  {
    q: 'How do the 5 free trial sessions work?',
    a: 'Every newly created account automatically receives 5 free trial sessions (up to 10 minutes each). You can launch the live copilot or test it in practice mode with zero upfront payment or credit card required.',
  },
  {
    q: 'How fast does it detect questions and generate answers?',
    a: 'Under 1.2 seconds! Powered by streaming Whisper-1 audio transcription and low-latency LLM inference, questions asked by the interviewer are processed and drafted into structured STAR talking points or syntax-highlighted code in real time.',
  },
  {
    q: 'Does it tailor answers to my actual resume and experience?',
    a: 'Yes. You can upload your CV or resume and paste the target job description. The AI connects your real career history, projects, and target role requirements so answers sound authentic and personal.',
  },
  {
    q: 'What languages and technical domains are supported?',
    a: 'All major languages: Python, JavaScript, TypeScript, Go, Java, C++, Rust, SQL, system architecture diagrams, and frontend/backend frameworks.',
  },
  {
    q: 'Can I purchase single credits without a recurring subscription?',
    a: 'Yes! In addition to Weekly ($39) and Monthly ($74.95) unlimited subscriptions, you can purchase one-time credit packs starting at $19 for 1 session, $29.50 for 3 sessions, or our most popular 8-session value pack.',
  },
];

export default function Simple3DLandingPage({
  user,
  themeMode,
  toggleTheme,
  onLoginClick,
  onSignupClick,
  onGetStarted,
  onSelectPlan,
}) {
  const [activePreset, setActivePreset] = useState(SIM_PRESETS[0]);
  const [openFaq, setOpenFaq] = useState(0);
  const [subscriberEmail, setSubscriberEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  return (
    <div className="pk-landing-root" id="hero">
      {/* Top Launch Offer Banner */}
      <div className="pk-top-banner">
        <span>🎉 Special Offer: 5 Free Trial Sessions Included • Use Code <strong>FEONIX50</strong> for 50% Off Plans</span>
        <a href="#pricing">View Pricing &rarr;</a>
      </div>

      {/* Parakeet-Style Navbar */}
      <Navbar3D
        user={user}
        themeMode={themeMode}
        toggleTheme={toggleTheme}
        onLoginClick={onLoginClick}
        onSignupClick={onSignupClick}
        onAdminClick={onLoginClick}
        onDashboardClick={onGetStarted}
      />

      <div className="pk-container">
        {/* ================================================================
            PARAKEET-STYLE HERO SECTION
            ================================================================ */}
        <section className="pk-hero-section">
          <div className="pk-badge">
            <span className="pk-pulse-dot" />
            <span>The Real-Time AI Interview Assistant</span>
          </div>

          <h1 className="pk-hero-headline">
            Get the right answer <br />
            <span className="pk-hero-highlight">while you're still talking</span>
          </h1>

          <p className="pk-hero-subheadline">
            Through technical interviews, system design rounds, live coding, and client calls where freezing up isn't an option.
            An invisible teleprompter that detects questions and streams answers in under 1.2s.
          </p>

          <div className="pk-hero-cta-group">
            <button onClick={onSignupClick} className="pk-btn-primary">
              <Sparkles size={18} />
              Start Free Trial · 5 Sessions
            </button>
            <a href="#simulator" className="pk-btn-secondary">
              <Zap size={18} />
              Interactive Simulator
            </a>
          </div>

          {/* Trust points row */}
          <div className="pk-trust-pills">
            <div className="pk-trust-item">
              <CheckCircle2 size={15} style={{ color: '#22c55e' }} />
              <span>100% Invisible to Zoom, Teams & Meet</span>
            </div>
            <div className="pk-trust-item">
              <CheckCircle2 size={15} style={{ color: '#22c55e' }} />
              <span>5 Free Trial Sessions Included</span>
            </div>
            <div className="pk-trust-item">
              <CheckCircle2 size={15} style={{ color: '#22c55e' }} />
              <span>STAR & Live Code Intelligence</span>
            </div>
          </div>

          {/* PARAKEET SIGNATURE HERO MOCKUP (OFFICIAL 4K ASSET) */}
          <div className="pk-parakeet-hero-stage">
            <div className="pk-parakeet-hero-frame">
              <img
                src="/images/parakeet_root_hero.webp"
                alt="Feonix AI - Real-time Interview Copilot Stealth Teleprompter"
                className="pk-parakeet-hero-image"
              />
            </div>
          </div>
        </section>



        {/* ================================================================
            PLATFORM COMPATIBILITY STRIP
            ================================================================ */}
        <section className="pk-compatibility-strip">
          <div className="pk-strip-title">Works seamlessly with your meeting and coding platforms</div>
          <div className="pk-platforms-list">
            {COMPATIBLE_PLATFORMS.map((platform) => (
              <div key={platform} className="pk-platform-chip">
                <Video size={14} style={{ color: '#22c55e' }} />
                <span>{platform}</span>
              </div>
            ))}
          </div>
        </section>

        {/* ================================================================
            PARAKEET FLOATING HUD SHOWCASE GALLERY
            ================================================================ */}
        <section id="hud-gallery" style={{ padding: '40px 0 20px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">Signature Stealth Interface</div>
            <h2 className="pk-section-h2">The Floating Overlay Across Real Scenarios</h2>
            <p className="pk-section-sub">
              See the exact floating capsule, speech-to-text token chips, and instant answer teleprompter hovering over live video calls and coding IDEs.
            </p>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '22px', marginBottom: '50px' }}>
            {/* Card 1: Zoom / Teams Call */}
            <div style={{ background: 'var(--pk-card)', border: '1px solid var(--pk-border)', borderRadius: '18px', overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'all 0.25s ease' }}>
              <div style={{ position: 'relative', overflow: 'hidden', height: '230px', background: '#000000' }}>
                <img
                  src="/images/feonix_live_floating_hud_call.jpg"
                  alt="Zoom & Teams Live Video Call HUD"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <span style={{ position: 'absolute', top: '12px', left: '12px', background: 'rgba(10, 15, 26, 0.85)', border: '1px solid rgba(34, 197, 94, 0.45)', color: '#4ade80', fontSize: '11px', fontWeight: 700, padding: '4px 10px', borderRadius: '6px', backdropFilter: 'blur(8px)' }}>
                  Live Zoom / Teams Call
                </span>
                <span style={{ position: 'absolute', bottom: '12px', right: '12px', background: 'rgba(0, 0, 0, 0.75)', color: '#ffffff', fontSize: '10.5px', padding: '3px 8px', borderRadius: '4px', fontFamily: 'monospace' }}>
                  100% Screen-Share Invisible
                </span>
              </div>
              <div style={{ padding: '20px' }}>
                <div style={{ fontSize: '11px', color: '#4ade80', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' }}>
                  Architecture & Cache Stampedes
                </div>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#ffffff', fontWeight: 700 }}>
                  Real-Time Video Call Teleprompter
                </h4>
                <p style={{ margin: 0, fontSize: '13px', color: '#94a3b8', lineHeight: 1.5 }}>
                  Floating capsule HUD captures spoken questions and streams XFetch algorithm and Redis mutex locks in under 1.2s.
                </p>
              </div>
            </div>

            {/* Card 2: CoderPad / LeetCode IDE */}
            <div style={{ background: 'var(--pk-card)', border: '1px solid var(--pk-border)', borderRadius: '18px', overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'all 0.25s ease' }}>
              <div style={{ position: 'relative', overflow: 'hidden', height: '230px', background: '#000000' }}>
                <img
                  src="/images/feonix_coding_floating_hud_ide.jpg"
                  alt="CoderPad & LeetCode IDE HUD"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <span style={{ position: 'absolute', top: '12px', left: '12px', background: 'rgba(10, 15, 26, 0.85)', border: '1px solid rgba(56, 189, 248, 0.45)', color: '#38bdf8', fontSize: '11px', fontWeight: 700, padding: '4px 10px', borderRadius: '6px', backdropFilter: 'blur(8px)' }}>
                  Live Coding Pad / IDE
                </span>
                <span style={{ position: 'absolute', bottom: '12px', right: '12px', background: 'rgba(0, 0, 0, 0.75)', color: '#ffffff', fontSize: '10.5px', padding: '3px 8px', borderRadius: '4px', fontFamily: 'monospace' }}>
                  O(1) Algorithms & Code
                </span>
              </div>
              <div style={{ padding: '20px' }}>
                <div style={{ fontSize: '11px', color: '#38bdf8', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' }}>
                  Data Structures & Algorithms
                </div>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#ffffff', fontWeight: 700 }}>
                  Syntax-Highlighted Code Assistant
                </h4>
                <p style={{ margin: 0, fontSize: '13px', color: '#94a3b8', lineHeight: 1.5 }}>
                  Overlays on CoderPad and HackerRank with runnable code solutions, Hash Map logic, and Big-O complexity notes.
                </p>
              </div>
            </div>

            {/* Card 3: Signature Parakeet Overlay */}
            <div style={{ background: 'var(--pk-card)', border: '1px solid var(--pk-border)', borderRadius: '18px', overflow: 'hidden', display: 'flex', flexDirection: 'column', transition: 'all 0.25s ease' }}>
              <div style={{ position: 'relative', overflow: 'hidden', height: '230px', background: '#000000' }}>
                <img
                  src="/images/parakeet_overlay_reference.jpg"
                  alt="Parakeet Floating HUD Call Sessions"
                  style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                />
                <span style={{ position: 'absolute', top: '12px', left: '12px', background: 'rgba(10, 15, 26, 0.85)', border: '1px solid rgba(245, 158, 11, 0.45)', color: '#f59e0b', fontSize: '11px', fontWeight: 700, padding: '4px 10px', borderRadius: '6px', backdropFilter: 'blur(8px)' }}>
                  Signature Stealth HUD
                </span>
                <span style={{ position: 'absolute', bottom: '12px', right: '12px', background: 'rgba(0, 0, 0, 0.75)', color: '#ffffff', fontSize: '10.5px', padding: '3px 8px', borderRadius: '4px', fontFamily: 'monospace' }}>
                  Word Token Chips
                </span>
              </div>
              <div style={{ padding: '20px' }}>
                <div style={{ fontSize: '11px', color: '#f59e0b', fontWeight: 700, textTransform: 'uppercase', marginBottom: '4px' }}>
                  Discrete Speech Tokens
                </div>
                <h4 style={{ margin: '0 0 8px 0', fontSize: '16px', color: '#ffffff', fontWeight: 700 }}>
                  Rate Limiting & Public APIs
                </h4>
                <p style={{ margin: 0, fontSize: '13px', color: '#94a3b8', lineHeight: 1.5 }}>
                  Word-by-word transcription chips with token bucket logic, burst calculations, and thumbs up/down evaluation.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ================================================================
            DUAL-ENGINE ARCHITECTURE (COPILOT VS COACH)
            ================================================================ */}
        <section id="dual-engine" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">Two Powerful Modes</div>
            <h2 className="pk-section-h2">Live Interview Copilot vs. AI Mock Coach</h2>
            <p className="pk-section-sub">
              Whether you need live stealth assistance during an actual technical round or a relentless AI partner to practice mock interviews beforehand.
            </p>
          </div>

          <div className="pk-dual-mode-grid">
            {/* Mode 1: Live Copilot */}
            <div className="pk-mode-card featured">
              <div className="pk-mode-pill" style={{ background: 'rgba(34, 197, 94, 0.18)', color: '#4ade80' }}>
                <Zap size={12} />
                Mode 1: Live Technical Copilot
              </div>
              <h3 style={{ fontSize: '22px', fontWeight: 800, color: '#ffffff', margin: '0 0 10px 0' }}>
                Invisible Teleprompter for Live Interviews
              </h3>
              <p style={{ fontSize: '14px', color: '#94a3b8', lineHeight: 1.6, marginBottom: '20px' }}>
                Runs silently on your Mac or PC alongside Zoom, Teams, Meet, or browser coding environments. Transcribes what the interviewer asks and streams clean talking points or algorithms directly onto your screen.
              </p>

              <div style={{ borderRadius: '12px', overflow: 'hidden', border: '1px solid rgba(255, 255, 255, 0.1)', marginBottom: '20px' }}>
                <img
                  src="/images/feonix_stealth_hud_preview.jpg"
                  alt="Feonix Live Stealth Copilot"
                  style={{ width: '100%', height: '180px', objectFit: 'cover', display: 'block' }}
                />
              </div>

              <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 24px 0', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0 }} />
                  <span><strong>100% Screen-Share Invisible:</strong> Never captured by Zoom, Teams or Meet.</span>
                </li>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0 }} />
                  <span><strong>Sub-1.2s Latency:</strong> Real-time streaming answers before you even finish pausing.</span>
                </li>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0 }} />
                  <span><strong>STAR & Code Engine:</strong> Generates runnable syntax and structured architecture points.</span>
                </li>
              </ul>

              <button onClick={onSignupClick} className="pk-btn-primary" style={{ width: '100%', justifyContent: 'center' }}>
                Launch Live Copilot Mode
              </button>
            </div>

            {/* Mode 2: AI Mock Coach */}
            <div className="pk-mode-card">
              <div className="pk-mode-pill" style={{ background: 'rgba(56, 189, 248, 0.18)', color: '#38bdf8' }}>
                <Mic size={12} />
                Mode 2: Voice Practice Coach
              </div>
              <h3 style={{ fontSize: '22px', fontWeight: 800, color: '#ffffff', margin: '0 0 10px 0' }}>
                Real-Time Voice Mock Interview Simulator
              </h3>
              <p style={{ fontSize: '14px', color: '#94a3b8', lineHeight: 1.6, marginBottom: '20px' }}>
                Speak out loud with an ultra-realistic AI interviewer that asks probing technical follow-ups, evaluates your speech cadence, counts filler words, and delivers actionable scorecards.
              </p>

              <div style={{ borderRadius: '12px', overflow: 'hidden', border: '1px solid rgba(255, 255, 255, 0.1)', marginBottom: '20px' }}>
                <img
                  src="/images/coach_mode_preview.jpg"
                  alt="Feonix AI Practice Coach"
                  style={{ width: '100%', height: '180px', objectFit: 'cover', display: 'block' }}
                />
              </div>

              <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 24px 0', display: 'flex', flexDirection: 'column', gap: '10px' }}>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span><strong>Conversational Voice AI:</strong> Realistic spoken interviews with adaptive follow-ups.</span>
                </li>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span><strong>Instant Scorecard:</strong> Grades STAR structure, technical depth, and delivery clarity.</span>
                </li>
                <li style={{ display: 'flex', alignItems: 'center', gap: '8px', fontSize: '13.5px', color: '#cbd5e1' }}>
                  <CheckCircle2 size={16} style={{ color: '#38bdf8', flexShrink: 0 }} />
                  <span><strong>Speech Cadence Tracker:</strong> Detects nervous rushing, filler words ("um", "like"), and pauses.</span>
                </li>
              </ul>

              <button onClick={onSignupClick} className="pk-btn-secondary" style={{ width: '100%', justifyContent: 'center' }}>
                Start Mock Voice Session
              </button>
            </div>
          </div>
        </section>

        {/* ================================================================
            CAREER INTELLIGENCE SUITE (4 PROJECT TOOLS)
            ================================================================ */}
        <section id="career-suite" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">All-In-One Career Intelligence</div>
            <h2 className="pk-section-h2">Everything You Need From Application to Offer</h2>
            <p className="pk-section-sub">
              Feonix AI isn't just an interview teleprompter. It's a complete end-to-end career suite designed to maximize your application conversion rate.
            </p>
          </div>

          {/* Full Suite Visual Showcase Banner */}
          <div style={{ marginBottom: '32px', borderRadius: '20px', overflow: 'hidden', border: '1px solid var(--pk-border)', position: 'relative' }}>
            <img
              src="/images/feonix_ai_career_suite.jpg"
              alt="Feonix AI Career Suite Architecture"
              style={{ width: '100%', height: 'auto', maxHeight: '360px', objectFit: 'cover', display: 'block' }}
            />
            <div style={{ position: 'absolute', bottom: 0, insetInline: 0, padding: '24px 30px', background: 'linear-gradient(to top, rgba(9, 13, 22, 0.95) 0%, rgba(9, 13, 22, 0.5) 70%, transparent 100%)', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '16px' }}>
              <div>
                <div style={{ fontSize: '18px', fontWeight: 800, color: '#ffffff' }}>4 Interconnected Career Intelligence Engines</div>
                <div style={{ fontSize: '13px', color: '#cbd5e1' }}>Resume Builder • Job Gap Analyzer • Cover Letters • Application Tracker</div>
              </div>
              <button onClick={onSignupClick} className="pk-btn-primary" style={{ padding: '10px 22px', fontSize: '13.5px' }}>
                Explore Career Suite
              </button>
            </div>
          </div>

          {/* 4 Cards Grid */}
          <div className="pk-suite-grid">
            {CAREER_SUITE.map((tool) => {
              const IconComp = tool.icon;
              return (
                <div key={tool.id} className="pk-suite-card">
                  <div className="pk-suite-icon" style={{ background: tool.bgColor, color: tool.color }}>
                    <IconComp size={22} />
                  </div>
                  <h3 style={{ fontSize: '17px', fontWeight: 700, color: '#ffffff', margin: '0 0 6px 0' }}>
                    {tool.title}
                  </h3>
                  <p style={{ fontSize: '12.5px', color: '#94a3b8', lineHeight: 1.5, margin: '0 0 16px 0' }}>
                    {tool.subtitle}
                  </p>
                  <ul style={{ listStyle: 'none', padding: 0, margin: 0, display: 'flex', flexDirection: 'column', gap: '8px', marginTop: 'auto' }}>
                    {tool.features.map((feat, idx) => (
                      <li key={idx} style={{ display: 'flex', alignItems: 'flex-start', gap: '8px', fontSize: '12px', color: '#cbd5e1', lineHeight: 1.4 }}>
                        <Check size={14} style={{ color: tool.color, flexShrink: 0, marginTop: '2px' }} />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </section>

        {/* ================================================================
            BEFORE VS AFTER FEONIX AI COMPARISON
            ================================================================ */}
        <section id="comparison" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">The Competitive Advantage</div>
            <h2 className="pk-section-h2">Interviewing Without Feonix vs. With Feonix</h2>
            <p className="pk-section-sub">
              See the exact difference between relying on memory alone and having a real-time invisible intelligence copilot in your corner.
            </p>
          </div>

          <div className="pk-comparison-grid">
            {/* The Old Way */}
            <div className="pk-compare-col before">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                <XCircle size={20} style={{ color: '#ef4444' }} />
                <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#ef4444', margin: 0 }}>
                  Without Feonix AI (The Old Way)
                </h3>
              </div>
              <p style={{ fontSize: '13px', color: '#94a3b8', margin: '0 0 16px 0' }}>
                Vulnerable to unexpected edge cases, brain freezes, and high-stress nervousness.
              </p>
              <ul className="pk-compare-list">
                <li className="pk-compare-item">
                  <XCircle size={16} style={{ color: '#ef4444', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#cbd5e1' }}>Freezing up and blanking out on niche system design or tricky algorithm questions</span>
                </li>
                <li className="pk-compare-item">
                  <XCircle size={16} style={{ color: '#ef4444', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#cbd5e1' }}>Awkward 15-second silences while frantically trying to remember rare API syntax</span>
                </li>
                <li className="pk-compare-item">
                  <XCircle size={16} style={{ color: '#ef4444', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#cbd5e1' }}>Rambling, unstructured behavioral answers that fail standard STAR grading rubrics</span>
                </li>
                <li className="pk-compare-item">
                  <XCircle size={16} style={{ color: '#ef4444', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#cbd5e1' }}>Debilitating imposter syndrome and interview anxiety costing high-compensation offers</span>
                </li>
              </ul>
            </div>

            {/* With Feonix AI */}
            <div className="pk-compare-col after">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '10px' }}>
                <CheckCircle2 size={20} style={{ color: '#22c55e' }} />
                <h3 style={{ fontSize: '18px', fontWeight: 800, color: '#4ade80', margin: 0 }}>
                  With Feonix AI (The Stealth Advantage)
                </h3>
              </div>
              <p style={{ fontSize: '13px', color: '#94a3b8', margin: '0 0 16px 0' }}>
                Instant composure, structured bullet points, and code algorithms streamed in sub-1.2s.
              </p>
              <ul className="pk-compare-list">
                <li className="pk-compare-item">
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#ffffff' }}>Instant talking points appear on your screen before you even finish acknowledging the question</span>
                </li>
                <li className="pk-compare-item">
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#ffffff' }}>Clean, optimal code solutions and time/space complexity notes for live coding pads</span>
                </li>
                <li className="pk-compare-item">
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#ffffff' }}>Answers personalized directly to your uploaded CV and real past engineering accomplishments</span>
                </li>
                <li className="pk-compare-item">
                  <CheckCircle2 size={16} style={{ color: '#22c55e', flexShrink: 0, marginTop: '3px' }} />
                  <span style={{ color: '#ffffff' }}>100% undetected screen-share exclusion on Zoom, Teams, Meet, CoderPad and HackerRank</span>
                </li>
              </ul>
            </div>
          </div>
        </section>

        {/* ================================================================
            CORE PARAKEET CAPABILITIES (4 PILLARS)
            ================================================================ */}
        <section id="features" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">Core Capabilities</div>
            <h2 className="pk-section-h2">Engineered for Technical Mastery</h2>
            <p className="pk-section-sub">
              Everything built into Feonix AI is optimized for speed, precision, and complete invisibility on live calls.
            </p>
          </div>

          <div className="pk-features-grid">
            <div className="pk-feature-box">
              <div className="pk-feature-icon">
                <Mic size={24} />
              </div>
              <h3 className="pk-feature-title">Real-Time Spoken Question Detection</h3>
              <p className="pk-feature-desc">
                Dual audio channels quietly process both interviewer audio and your microphone simultaneously.
                Spoken questions are captured and transcribed in sub-second chunks using streaming Whisper models.
              </p>
            </div>

            <div className="pk-feature-box">
              <div className="pk-feature-icon">
                <FileText size={24} />
              </div>
              <h3 className="pk-feature-title">Resume & Job Context Personalization</h3>
              <p className="pk-feature-desc">
                Upload your actual resume and paste the target job description. The AI connects your real career history
                and past achievements so generated answers highlight your authentic background.
              </p>
            </div>

            <div className="pk-feature-box">
              <div className="pk-feature-icon">
                <EyeOff size={24} />
              </div>
              <h3 className="pk-feature-title">100% Undetectable Screen-Share Protection</h3>
              <p className="pk-feature-desc">
                Proprietary window capture exclusion guarantees that when you share your full desktop or application window on Zoom,
                Teams, or Meet, interviewers see only your editor or browser—never the Feonix HUD.
              </p>
            </div>

            <div className="pk-feature-box">
              <div className="pk-feature-icon">
                <Code2 size={24} />
              </div>
              <h3 className="pk-feature-title">STAR Framework & Live Coding Engine</h3>
              <p className="pk-feature-desc">
                Switch seamlessly between behavioral questions (Situation, Task, Action, Result) and complex coding rounds
                with syntax-highlighted algorithms in Python, JavaScript, Java, Go, C++, and SQL.
              </p>
            </div>
          </div>
        </section>

        {/* ================================================================
            PRACTICE MODE / SIMULATOR
            ================================================================ */}
        <section id="simulator" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">Interactive Preview</div>
            <h2 className="pk-section-h2">Test Drive the Copilot in Practice Mode</h2>
            <p className="pk-section-sub">
              Select any scenario below to see how the stealth overlay captures questions and structures talking points in real time.
            </p>
          </div>

          <div className="pk-simulator-card">
            {/* Left Nav */}
            <div className="pk-sim-tabs">
              <span style={{ fontSize: '11px', fontWeight: 800, color: 'var(--pk-text-muted)', textTransform: 'uppercase', marginBottom: '4px' }}>
                Select Scenario
              </span>
              {SIM_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  onClick={() => setActivePreset(preset)}
                  className={`pk-sim-tab-btn ${activePreset.id === preset.id ? 'is-active' : ''}`}
                >
                  <div style={{ fontSize: '13.5px', fontWeight: 600 }}>{preset.title}</div>
                  <div style={{ fontSize: '11.5px', color: 'var(--pk-text-muted)', marginTop: '2px' }}>
                    {preset.category}
                  </div>
                </button>
              ))}
            </div>

            {/* Right Display */}
            <div className="pk-sim-view">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid rgba(255, 255, 255, 0.08)', paddingBottom: '12px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ width: '8px', height: '8px', borderRadius: '50%', background: '#22c55e' }} />
                  <span style={{ fontSize: '12.5px', fontWeight: 600, color: '#4ade80' }}>{activePreset.category}</span>
                </div>
                <span style={{ fontSize: '12px', color: '#22c55e', fontFamily: 'monospace' }}>● 0.9s Latency</span>
              </div>

              {/* Detected Question */}
              <div style={{ background: 'rgba(255, 255, 255, 0.02)', padding: '12px 16px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                <span style={{ fontSize: '11px', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700 }}>Question:</span>
                <p style={{ margin: '4px 0 0 0', fontSize: '14.5px', fontWeight: 600, color: '#ffffff' }}>
                  "{activePreset.question}"
                </p>
              </div>

              {/* Bullet Points */}
              <div style={{ background: 'rgba(34, 197, 94, 0.05)', padding: '14px 16px', borderRadius: '10px', border: '1px solid rgba(34, 197, 94, 0.2)' }}>
                <span style={{ fontSize: '11px', color: '#4ade80', textTransform: 'uppercase', fontWeight: 700 }}>
                  Structured Talking Points:
                </span>
                <ul style={{ margin: '8px 0 0 0', paddingLeft: '18px', fontSize: '13px', lineHeight: 1.6, color: '#f1f5f9' }}>
                  {activePreset.talkingPoints.map((pt, idx) => (
                    <li key={idx} style={{ marginBottom: '4px' }}>{pt}</li>
                  ))}
                </ul>
              </div>

              {/* Code if applicable */}
              {activePreset.code && (
                <div style={{ background: 'rgba(0, 0, 0, 0.6)', padding: '12px 16px', borderRadius: '10px', border: '1px solid rgba(255, 255, 255, 0.08)' }}>
                  <span style={{ fontSize: '11px', color: '#38bdf8', textTransform: 'uppercase', fontWeight: 700, display: 'block', marginBottom: '6px' }}>
                    Code Solution / Algorithm:
                  </span>
                  <pre style={{ margin: 0, fontSize: '12px', color: '#4ade80', fontFamily: 'monospace', overflowX: 'auto', lineHeight: 1.5 }}>
                    {activePreset.code}
                  </pre>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* ================================================================
            TESTIMONIALS & CANDIDATE SUCCESS STORIES
            ================================================================ */}
        <section id="testimonials" style={{ padding: '30px 0' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">Candidate Stories</div>
            <h2 className="pk-section-h2">Trusted by Engineers Landing Top Tech Roles</h2>
            <p className="pk-section-sub">
              From FAANG to high-growth startups, candidates use Feonix AI to stay composed, answer instantly, and secure dream offers.
            </p>
          </div>

          <div className="pk-testimonials-grid">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="pk-testimonial-card">
                <div>
                  <div style={{ display: 'flex', gap: '3px', marginBottom: '14px' }}>
                    {[...Array(t.rating)].map((_, idx) => (
                      <Star key={idx} size={15} fill="#f59e0b" color="#f59e0b" />
                    ))}
                  </div>
                  <p style={{ fontSize: '13.5px', color: '#cbd5e1', lineHeight: 1.6, margin: '0 0 20px 0', fontStyle: 'italic' }}>
                    "{t.quote}"
                  </p>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '12px', borderTop: '1px solid rgba(255, 255, 255, 0.06)', paddingTop: '14px' }}>
                  <div style={{ width: '38px', height: '38px', borderRadius: '50%', background: 'linear-gradient(135deg, #22c55e, #06b6d4)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, fontSize: '13px', color: '#ffffff' }}>
                    {t.avatar}
                  </div>
                  <div>
                    <div style={{ fontSize: '14px', fontWeight: 700, color: '#ffffff' }}>{t.name}</div>
                    <div style={{ fontSize: '11.5px', color: '#94a3b8' }}>{t.role}</div>
                    <div style={{ fontSize: '11px', color: '#4ade80', fontWeight: 600 }}>{t.company}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* ================================================================
            PARAKEET PRICING & CREDIT PACKS
            ================================================================ */}
        <section id="pricing" style={{ padding: '30px 0' }}>
          <ParakeetPricingView onSelectPlan={onSelectPlan} />
        </section>

        {/* ================================================================
            FAQ SECTION
            ================================================================ */}
        <section id="faq" style={{ padding: '30px 0', maxWidth: '820px', margin: '0 auto' }}>
          <div className="pk-section-header">
            <div className="pk-section-tag">FAQ</div>
            <h2 className="pk-section-h2">Frequently Asked Questions</h2>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {FAQS.map((faq, idx) => {
              const isOpen = openFaq === idx;
              return (
                <div
                  key={idx}
                  style={{
                    background: 'var(--pk-card)',
                    border: '1px solid var(--pk-border)',
                    borderRadius: '14px',
                    overflow: 'hidden',
                  }}
                >
                  <button
                    onClick={() => setOpenFaq(isOpen ? null : idx)}
                    style={{
                      width: '100%',
                      padding: '18px 20px',
                      background: 'transparent',
                      border: 'none',
                      color: '#ffffff',
                      fontSize: '15px',
                      fontWeight: 600,
                      textAlign: 'left',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      cursor: 'pointer',
                    }}
                  >
                    <span>{faq.q}</span>
                    <ChevronDown
                      size={18}
                      style={{
                        transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
                        transition: 'transform 0.2s ease',
                        color: 'var(--pk-text-muted)',
                      }}
                    />
                  </button>
                  {isOpen && (
                    <div style={{ padding: '0 20px 18px 20px', fontSize: '14px', color: 'var(--pk-text-muted)', lineHeight: 1.6 }}>
                      {faq.a}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* ================================================================
            HIGH-CONVERTING CTA BANNER
            ================================================================ */}
        <section className="pk-cta-banner">
          <h2 style={{ fontSize: 'clamp(28px, 4vw, 40px)', fontWeight: 800, color: '#ffffff', margin: '0 0 14px 0' }}>
            Get the right answer while you're still talking
          </h2>
          <p style={{ fontSize: '16px', color: '#cbd5e1', maxWidth: '620px', margin: '0 auto 30px auto', lineHeight: 1.6 }}>
            Join thousands of candidates who use Feonix AI to stay composed, answer instantly, and secure top offers.
          </p>
          <button onClick={onSignupClick} className="pk-btn-primary" style={{ padding: '16px 36px', fontSize: '16px' }}>
            <Sparkles size={20} />
            Start with 5 Free Sessions Now
          </button>
        </section>

        {/* ================================================================
            RICH DETAILED FOOTER
            ================================================================ */}
        <footer className="pk-footer">
          {/* Top Newsletter / Resource Card */}
          <div className="pk-footer-newsletter-card">
            <div className="pk-footer-newsletter-info">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#4ade80', fontSize: '12px', fontWeight: 700, textTransform: 'uppercase', marginBottom: '6px' }}>
                <Sparkles size={14} />
                <span>Weekly Technical Interview Kit</span>
              </div>
              <h3 className="pk-footer-newsletter-h3">
                Get LeetCode algorithms & System Design blueprints
              </h3>
              <p className="pk-footer-newsletter-desc">
                Join 18,000+ engineers receiving curated FAANG interview question breakdowns, STAR behavioral templates, and real-time copilot updates.
              </p>
            </div>

            <form
              className="pk-footer-newsletter-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (subscriberEmail) setSubscribed(true);
              }}
            >
              {subscribed ? (
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: '#4ade80', fontSize: '14px', fontWeight: 600, padding: '10px 16px', background: 'rgba(34, 197, 94, 0.15)', borderRadius: '10px', border: '1px solid rgba(34, 197, 94, 0.3)' }}>
                  <CheckCircle2 size={18} />
                  <span>You're in! Check your inbox for the System Design cheatsheet.</span>
                </div>
              ) : (
                <>
                  <input
                    type="email"
                    required
                    placeholder="Enter your work or personal email..."
                    value={subscriberEmail}
                    onChange={(e) => setSubscriberEmail(e.target.value)}
                    className="pk-footer-input"
                  />
                  <button type="submit" className="pk-btn-primary" style={{ padding: '12px 20px', fontSize: '13px', whiteSpace: 'nowrap' }}>
                    Subscribe Free
                  </button>
                </>
              )}
            </form>
          </div>

          {/* 5-Column Navigation Grid */}
          <div className="pk-footer-grid">
            {/* Column 1: Brand & Security Mission */}
            <div className="pk-footer-col">
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '12px' }}>
                <span style={{ width: '28px', height: '28px', borderRadius: '7px', background: 'linear-gradient(135deg, #16a34a, #06b6d4)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '14px', color: '#ffffff' }}>
                  F
                </span>
                <span style={{ fontSize: '18px', fontWeight: 800, letterSpacing: '0.04em', color: '#ffffff' }}>
                  FEONIX<span style={{ color: '#4ade80' }}>AI</span>
                </span>
              </div>
              <p style={{ fontSize: '13px', color: '#94a3b8', lineHeight: 1.6, margin: '0 0 14px 0' }}>
                The undetectable, real-time AI interview copilot and career intelligence suite. Helping software engineers, architects, and engineering managers land top-tier offers with unshakeable confidence.
              </p>

              {/* Real-time Status Badge */}
              <div className="pk-footer-status-pill">
                <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#22c55e', boxShadow: '0 0 8px #22c55e' }} />
                <span>All Systems Operational · 99.98% Uptime</span>
              </div>

              {/* Trust & Privacy Guarantee */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '12px', color: '#cbd5e1' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <ShieldCheck size={14} style={{ color: '#22c55e' }} />
                  <span>100% Screen-Share Invisible</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <Lock size={14} style={{ color: '#22c55e' }} />
                  <span>Zero Audio Recording Storage Guarantee</span>
                </div>
              </div>
            </div>

            {/* Column 2: Products & Modules */}
            <div className="pk-footer-col">
              <h4 className="pk-footer-col-title">Platform Suite</h4>
              <ul className="pk-footer-list">
                <li><a href="#dual-engine" className="pk-footer-link">Live Interview Copilot <span className="pk-footer-badge">Live</span></a></li>
                <li><a href="#dual-engine" className="pk-footer-link">AI Mock Practice Coach</a></li>
                <li><a href="#career-suite" className="pk-footer-link">ATS Resume Builder</a></li>
                <li><a href="#career-suite" className="pk-footer-link">Job Match & Gap Analyzer</a></li>
                <li><a href="#career-suite" className="pk-footer-link">AI Cover Letter Generator</a></li>
                <li><a href="#career-suite" className="pk-footer-link">Application Pipeline Tracker</a></li>
                <li><a href="#simulator" className="pk-footer-link">Interactive Simulator</a></li>
              </ul>
            </div>

            {/* Column 3: Platform Compatibility */}
            <div className="pk-footer-col">
              <h4 className="pk-footer-col-title">Compatibility</h4>
              <ul className="pk-footer-list">
                <li><a href="#hero" className="pk-footer-link">Zoom Video Meeting</a></li>
                <li><a href="#hero" className="pk-footer-link">Google Meet Screen-Share</a></li>
                <li><a href="#hero" className="pk-footer-link">Microsoft Teams Desktop</a></li>
                <li><a href="#hero" className="pk-footer-link">Webex by Cisco</a></li>
                <li><a href="#hud-gallery" className="pk-footer-link">CoderPad & HackerRank</a></li>
                <li><a href="#hud-gallery" className="pk-footer-link">LeetCode & CodeSignal</a></li>
                <li><a href="#hero" className="pk-footer-link">Windows & macOS Native</a></li>
              </ul>
            </div>

            {/* Column 4: Interview Resources */}
            <div className="pk-footer-col">
              <h4 className="pk-footer-col-title">Resources & Guides</h4>
              <ul className="pk-footer-list">
                <li><a href="#comparison" className="pk-footer-link">System Design Playbook</a></li>
                <li><a href="#comparison" className="pk-footer-link">STAR Behavioral Matrix</a></li>
                <li><a href="#hud-gallery" className="pk-footer-link">Big-O Cheat Sheet</a></li>
                <li><a href="#hud-gallery" className="pk-footer-link">Live Coding Walkthroughs</a></li>
                <li><a href="#testimonials" className="pk-footer-link">Candidate Success Stories</a></li>
                <li><a href="#faq" className="pk-footer-link">Technical FAQs</a></li>
                <li><a href="mailto:support@feonixai.com" className="pk-footer-link"><Mail size={13} /> Contact Engineering</a></li>
              </ul>
            </div>

            {/* Column 5: Plans & Security */}
            <div className="pk-footer-col">
              <h4 className="pk-footer-col-title">Pricing & Trust</h4>
              <ul className="pk-footer-list">
                <li><a href="#pricing" className="pk-footer-link">5 Free Trial Sessions</a></li>
                <li><a href="#pricing" className="pk-footer-link">1-Session Pack ($19)</a></li>
                <li><a href="#pricing" className="pk-footer-link">3-Session Pack ($29.50)</a></li>
                <li><a href="#pricing" className="pk-footer-link">Weekly Unlimited ($39)</a></li>
                <li><a href="#pricing" className="pk-footer-link">Monthly Unlimited ($74.95)</a></li>
                <li><a href="#faq" className="pk-footer-link">Privacy Policy</a></li>
                <li><a href="#faq" className="pk-footer-link">Stealth Protection Whitepaper</a></li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar: Copyright & Global Badges */}
          <div className="pk-footer-bottom-bar">
            <div>
              © {new Date().getFullYear()} Feonix AI Inc. All rights reserved. Built for technical candidates worldwide.
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '20px', flexWrap: 'wrap' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: '6px' }}>
                <Globe size={13} style={{ color: '#4ade80' }} />
                <span>Global Multi-Region Inference</span>
              </span>
              <span>•</span>
              <span>Sub-1.2s Latency</span>
              <span>•</span>
              <span>256-Bit TLS Encryption</span>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
}
